<style>
    nav{
        max-height:0px;
    }
.drop{
    width: 200px;
    height:50px;
}
.dropdown{
    position:relative;
    display:inline-block;
}
.dropdown-content{
display:none;
position:absolute;
}
.dropdown-content a{
    display:block;
    color:black;
    padding:12px 16px;
    text-decoration:none;
}
</style>
<center>
<!-- <b><span style="background:#ecff83"><label class="col-sm-3 control-label" for="reports"><b> Choose report:</b></label></span></b> -->
<!-- <form action="" method="post" name="report">
<div class="form-group">
<div class="row"> -->
    
<!-- <select name="reports" id="reports" style="width: 200px; height: 50px;"> -->
<!-- <nav style="width: 200px; height: 50px;">
<ul style= "width: 200px; height: 50px;">
        <li style="width: 200px; height: 50px;"><a href="view_attendence.php">Indiviual report</a></li>
        <li style="width: 200px; height: 50px;"><a href="view_attendence.php">Indiviual report</a></li>
        </ul>
        </nav> -->

<!-- <a href="view_attendence.php"><option>Indiviual report</option></a>
<option value="report2.php" data-toggle="downdown"><a href="report.php">Mass report</a></option> -->
<!-- </select>
<div class="dropdown">
<button class="drop">reports</button>
<div class="dropdown-content">
    <a href="view_attendence.php">Individual Report</a>
    <a href="report2.php">Mass Report</a>
    
</div> -->
</div>
<!-- </div>
</form> -->
<style>
.dropbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>
</head>
<body>

<h2>Choose Report </h2>
<!-- <p>Move the mouse over the button to open the dropdown menu.</p> -->

<div class="dropdown">
  <button class="dropbtn">Reports</button>
  <div class="dropdown-content">
    <a href="view_attendence.php">Individual report</a>
    <a href="report2.php">Mass report</a>
    <a href="#">Link 3</a>
  </div>
</div>

</body>
</html>

</center>