<?php include('myhead.php');?>
<?php include('Admin.php');?> <br>
<?php
$query1="select * from `add_teacher`";
$result=mysqli_query($con,$query1);
?>
<center>
<table style="width:100%">
<tr class="even">
  <th>Employee id</th>
  <th>Name</th>
  <!-- <th>Last Name</th> -->
  <th>Email</th>
  <th>Password</th>
  <th>Gender</th>
  <th>DOB</th>
  <th>Contact</th>
  <th>Address</th>
  <th>Action???</th>
  </tr>
  <?php
  while($rows=mysqli_fetch_assoc($result)) {?>
  <tr class="odd">
  <td style="text-align:center"><?php echo $rows['Employee_id']; ?></td>
  <td><?php echo $rows['tname']; ?></td>
  <!-- <td><?php //echo $rows['tlname']; ?></td> -->
  <td><?php echo $rows['temail']; ?></td>
  <td><?php echo $rows['tpassword']; ?></td>
  <td><?php echo $rows['tgender']; ?></td>
  <td><?php echo $rows['tdob']; ?></td>
  <td><?php echo $rows['tcontact']; ?></td>
  <td><?php echo $rows['taddress']; ?></td>
  <td><button style="padding:0";><a href="EditTeacher.php?edit=<?php echo $rows['Employee_id']; ?>" class="edit">Edit</a></button>
  <button style="padding:0";><a href="DeleteTeacher.php?id=<?php echo $rows['Employee_id']; ?>"  onclick='return checkdelete()' class="delete">delete</a></button>
</td>
  </tr>
  <?php
  }
?>
</table>
<script>
  function checkdelete()
  {
    return confirm('Are you sure you want to delete this record');
  }
</script>