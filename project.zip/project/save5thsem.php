<?php include('myhead.php') ?>
<?php
//$name='';
//$subject='';
$update=false;
if(isset($_POST['1st_sem']))
if(isset($_POST['Name']))
$name=$_POST['Name'];
if(isset($_POST['Subject']))
$subject=$_POST['Subject'];
echo "good";
echo $name;
$query="INSERT into my_semester(Name,Subject,Semester) values('$name','$subject','5th Semester')";
echo "nice";
$run=mysqli_query($con,$query) or die(mysqli_error($con));
if($run)
{
  echo "form submitted";
  header('location:5thSem.php');
}

if(isset($_POST['edit'])){
    $id=$_GET['edit'];
    $update=true;
    $result=$mysqli->query("SELECT * from 1st_sem where id=$id") or die($mysqli->error());
    if(count($result)==1)
    {
        $row=$result->fetch_array();
        extract($row);
        $name=$row['Name'];
        $subject=$row['Subject'];
    }
}
?>
<?php
    //$q1="UPDATE `1st_sem` SET 'Name'=$name,`Subject`='$subject' WHERE `id`='".$_GET['id']."'";
   // $q1="UPDATE `1st_sem` SET 'Name'=$name,`Subject`='$subject' WHERE id=$id";
    // $query1="update '1st_sem' set Name='".$name."',Subject='".$subject."'";
    // $result1=mysqli_query($con,$q1);
    // if($result1)
    // {
    //   header('1stSem.php');
    // }
    // else
    // {
    //   die(mysqli_error($con));
    //   echo "cannot update";
    // }
    ?>