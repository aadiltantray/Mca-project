<?php include('myhead.php'); ?>
<?php 
echo "welcome";
?>
<style>
        ul{
             list-style-type: none;
             margin: 0;
             padding: 0;
             overflow: hidden;
             background-color: #333;
         }
         li{
             float: left;
         }
         li a{
             display: block;
             padding: 27px 68px;
             color: white;
             text-align: center;
             text-decoration: none;
     
             }
             li a:hover:not(.active){
                 background-color: white;
             }
             .active{
                 background-color: #4CAF50;
             }
             body{
                 background-color: #87FFBA;
             }
     </style>
</head>
<body>
    <!-- navigation bar -->
   <ul>
   <li>
        <a href="Home.php">Home</a>
    </li>    
    <li>
        <a href="AddTeacher.php" target="_blank">Add Teacher</a>
    </li>
    
    <li>
         <a href="viewTeacher.php">View Teacher</a>
    </li>
</li>
<li>
    
    <a href="view_student.php">View Student</a>
</li>
<li>
    <a href="view_attendence.php">ViewAttendence</a>
</li>
<li>
    <a href="main.html">Logout</a>
</li>
</ul>  