function myFunction(){
    alert("attendence is already recorded");
}