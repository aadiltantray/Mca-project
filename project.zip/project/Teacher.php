<?php include('myhead.php'); ?>
<?php 
echo "welcome";
?>
<style>
    /* .overlay{
height: 10%;
width=0;
position:fixed;

    } */

        ul{
             list-style-type: none;
             margin: -26;
             padding: 100;
             overflow-x: hidden;
             background-color: #333;
             display: flex;
         }
         li{
             /* float: left; */
             /* display: inline-block; */
             /* padding:27px; */

         }
         li a{
             display: block;
             padding: 27px 100px;
             color: white;
             text-align: center;
             text-decoration: none;
     
             }
             li a:hover:not(.active){
                 background-color: green;
             }
             .active{
                 background-color: #4CAF50;
                 padding:27px;
                 width:110px;
             }
             body{
                 background-color: #87FFBA;
             }
     </style>
</head>
<body>
    <!-- navigation bar -->
   <ul>
   <li>
        <a href="hometeacher.php" class="active">Home</a>
    </li>    
    
<li>
    
    <a href="view_students_by_teacher.php">View Student</a>
</li>
<li>
    <a href="add_attendence.php">Add Attendence</a>
</li>
<li>
    <a href="view_attend_by_teacher.php">View Attendence</a>
</li>
<li>
    <a href="main.html">Logout</a>
</li>
      

</ul>  