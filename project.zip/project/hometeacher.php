<?php
session_start();
include('myhead.php');
include('teacher.php');
//$name=$_GET['name'];
$name=$_SESSION['tname'];
?>
<br><br>
<style>
  td{
    text-align:center;
    width:10%;
    height:10%;
  }
  tr{
    height: 50px;
  }

</style>
<?php
//$query1="select * from 1st_sem";
$query1="SELECT * FROM my_semester WHERE Name='$name'";
$result=mysqli_query($con,$query1);
if($result)
{
  
}
else
{
echo mysqli_error($con);
}
?>
<center>
  <b style="background:#f5cbe8; font-size:30px">Subjects assigned to <?php echo $name?></b> <br><br>
<table style="width:60%">
 <tr class="even">
  <!-- <th>Name</th> -->
  <th>Subject</th>
  <th>Semester</th>
  <!-- <th>Action???</th> -->
  </tr>
  <?php
  while($rows=mysqli_fetch_assoc($result)) {?>

  <tr class="odd">
   
  <td><?php echo $rows['Subject']; ?></td>
  <td><?php echo $rows['Semester']; ?></td> 
  </tr>
  <?php
  }
  ?>