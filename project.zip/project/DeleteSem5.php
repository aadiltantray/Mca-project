<?php include('myhead.php');
echo "hello";
$id=$_GET['id'];
echo $id;
$query="DELETE FROM `my_semester` WHERE id=$id";
$result=mysqli_query($con,$query);
if($result)
{
    header('location:5thsem.php');
}
else
{
    echo "cannot delete";
    die(mysqli_error($con));
}
?>