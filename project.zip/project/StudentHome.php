<?php 
session_start();
include('myhead.php');?>
<?php include('stu_header.php')?>
<?php
$name=$_SESSION['sname'];
$semester=$_SESSION['ssemester'];
//$name=$_GET['name'];
//$semester=$_GET['semester'];
?>
<br>
 <center> <b style="background:#f5cbe8; font-size:30px">Welcome! <?php echo $name ?> here is the list of your subjects and corresponding teachers assigned. </center> <br> 
<center>
<table style="width:77%">
    <tr class="even">
        <th>Subject</th>
        <th>Teacher</th>
</tr>
<?php
$query="SELECT * from `my_semester` WHERE Semester='$semester'"; 
$result=mysqli_query($con,$query);
 while($rows=mysqli_fetch_array($result)){
     
      ?>
      <tr class="odd">
        <td>
            <?php echo $rows['Name']; ?>
        </td>
        <td> 
            <?php echo $rows['Subject'];?>
        </td>
    </tr>
    <?php
}
?>
</table>
</center>
