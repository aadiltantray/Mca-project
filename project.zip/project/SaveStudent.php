<?php include('myhead.php') ?>

<?php
$_SESSION['user']=0;
$_SESSION['success']=0;
$name=$_POST['sname'];
//$lastname=$_POST['tlname'];
$email=$_POST['semail'];
$semester=$_POST['ssemester'];
$roll_num=$_POST['srollnumber'];
$gender=$_POST['sgender'];
$dob=$_POST['sdob'];
$contact=$_POST['scontact'];
$address=$_POST['saddress'];
if(!empty($name) || !empty($email) || !empty($semester) || !empty($roll_num) || !empty($gender) || !empty($dob) || !empty($contact) || !empty($address)) {
echo "All fields are filled successfully";
$status=pending;
$SELECT="SELECT srollnumber from add_student where srollnumber = ? Limit 1";
$INSERT="INSERT Into add_student (sname, semail, ssemester, srollnumber, sgender, sdob,
 scontact, saddress, status) values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
 echo "Good";

//prepare statement
$stmt=$con->prepare($SELECT);
$stmt->bind_param("i",$roll_num);
$stmt->execute();
$stmt->bind_result($roll_num);
$stmt->store_result();
$rnum=$stmt->num_rows;
echo "nice";
if($rnum==0) {
    $stmt->close();
    $stmt=$con->prepare($INSERT);
    echo "better";
$stmt->bind_param("sssisiiss",$name,$email,$semester,$roll_num, $gender, $dob, $contact, $address, $status);
echo "oooooooooooo";
$stmt->execute();
echo "New record insert successfully";
$_SESSION['success']= 1;
header('location:LoginStudent.php');
}
else {
    
    echo "Someone already registered with this rollnumber";
    $_SESSION['user']= 1;
    echo $_SESSION['user'];
    header('location:SignupStudent.php');  
}

echo "do it";
$stmt->close();
$con->close();
//header('location:LoginStudent.php');
}

else {

    echo "All fields are required";
   // header('location:SignupStudent.php');
   die();
}
echo "thanku";
?>