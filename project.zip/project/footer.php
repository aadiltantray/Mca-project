
             <?php
             include('connect.php');
            
             ?>
             <?php //echo $row_footer['footer'];?>
             
            <footer class="footer" style="  position: fixed;left: 0;bottom: 0;width: 100%;text-align: center;"> © 2022 All rights reserved:<a href="https://www.youtube.com"> Aadil ||  9682399716    || aadil@gmail.com</a>
  <!-- before changing this footer you must have afsha's permission -->
</footer> 

            
       