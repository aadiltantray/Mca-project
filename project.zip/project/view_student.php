<?php session_start();?>
<?php include('myhead.php'); ?>
<?php
include('Admin.php');
?>
<center>
<style>
    .search{
        background:#f44336;
        border:none;
        text-align: center;
padding:13px 50px 33px;
font-size:16px;
        width:194px;
        height:20px;
        color:white;
        
        display: inline-block;
        cursor: pointer;
    }
</style>


<form action="view_student.php" method="POST" name="hello">
    <!-- <div style="width:200px"> -->
<div class="form-group">
<div class="row">
    <label class="col-sm-3 control-label">Semester</label>
    <div class="col-sm-9">
      <select type="text" name="ssemester" class="form-control" placeholder="Semester" id="event" onkeydown="return alphaOnly(event);" required="" style="width: 200px;">
      
      <option value="1st Semester">1st Semester</option>
      <option value="2nd Semester">2nd Semester</option>
      <option value="3rd Semester">3rd Semester</option>
      <option value="4th Semester">4th Semester</option>
      <option value="5th Semester">5th Semester</option>
      <option value="6th Semester">6th Semester</option>
</select>

    </div>
</div>
<br>

<!-- <div class="form-group">
   			<input type="submit" name="btn"  class="btn btn-danger col-md-2 col-md-offset-5" class="delete" style="border-radius:0%"  value="Search">
   		</div> -->
           <button class="search" name="btn">Search</button>
</div>

<br><br>
<?php
$semester='';
if(isset($_POST['btn'])){
//echo $_POST['ssemester'];
if(isset($_POST['ssemester'])){
$semester=$_POST['ssemester'];
?>
<table width=100%>
    <tr class="even">
        <th>Name</th>
        <th>Roll Number</th>
        <th>Semester</th>
        <th>Email</th>
    </tr>
<?php
$query="SELECT * FROM add_student where ssemester='$semester'";
$result=mysqli_query($con,$query);
$row=mysqli_num_rows($result);
if($row > 0){
 while($rows=mysqli_fetch_assoc($result)){

    ?>
    
<tr class="odd">
    <td><?php echo $rows['sname']; ?></td>
<td><?php echo $rows['srollnumber']; ?></td>
<td><?php echo $rows['ssemester']; ?></td>
<td><?php echo $rows['semail']; ?></td>
</tr>
<?php
}
}
else
{
echo "<h1><span style='color:#b17b18;background-color:white;'>No One Is Enroled In This Semester<span> </h1>";
}
?>
</form>
</table>
<?php
}
}

if(empty($semester)){
    $query="SELECT * FROM add_student where ssemester='1st Semester'";
    $result=mysqli_query($con,$query);
        $rows=mysqli_fetch_assoc($result);
    
        ?>
        <table width=100%>
        <tr class="even">
            <th>Name</th>
            <th>Roll Number</th>
            <th>Semester</th>
            <th>Email</th>
        </tr>
    <tr class="odd">
        <td><?php echo $rows['sname']; ?></td>
    <td><?php echo $rows['srollnumber']; ?></td>
    <td><?php echo $rows['ssemester']; ?></td>
    <td><?php echo $rows['semail']; ?></td>
    </tr>
    </table> 
    <?php
}
?>
</center>