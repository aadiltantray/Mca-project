<?php session_start(); ?>
<?php
include('myhead.php');
// if(isset($_POST['btn_login'])){
// if(isset($_POST['email'])==aemail)
// $email=$_POST['email'];
// if(isset($_POST['password']))
// $password=$_POST['password'];
// }
//  if($email==$_SESSION["aemail"] and $password==$_SESSION["apassword"])
// }
?>

    <style>
        .button {
  margin-bottom: 4px;
  padding: 8px 12px;
  border: 1px solid #75B9E1;
  border-radius: 3px;
  background: #4FA0D0;
  cursor: pointer;
  font-family: inherit;
  text-transform: uppercase;
  color: #fff;

}
h2{
    text-align: center;
    background-color: blue;
    }
    h3{
    text-align: center;
    background-color: rgb(145, 119, 168);
    }
        .img-container2 {
        text-align: center;
        
    }
    body
    {
       
        background-color:#6ccccc ;
        max-width=40%;
    }
    .popup__background {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 10000;
  height: 100%;
  width: 100%;
  background: rgba(0, 0, 0, 0.4);
  opacity: 0;
  transition: opacity 0.3s ease-in-out;
}
.popup__content {
  position: fixed;
  top: 50%;
  left: 50%;
  z-index: 10001;
  min-width: 400px;
  padding: 25px 50px;
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 3px;
  text-align: center;
  -webkit-animation: hide-popup 0.3s forwards;
          animation: hide-popup 0.3s forwards;
  /**
   * Popup types.
   */
}
.popup__content__title {
  margin-bottom: 10px;
  font-size: 28px;
  font-weight: 100;
  color: #626262;
}
    </style>
</head>
<body>
    <!-- <img src="p4.png" alt="loading"width="100%" height= "150"><br> -->
    <br>
    <br>
    <center>
    <?php 

if(isset($_SESSION['success'])){
if($_SESSION['success']){
echo '<div class="alert alert-danger alert-dismissible fade show" role="alert" style="background-color:#f57c7c; width:40%; height: 30px">
<strong>Success: </strong> You have successfully registered
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
</button>
</div>';
}}

?> 
    <span background color="blue"><b> ATTENDENCE AUTOMATION SYSTEM</b></span>
    <br>
    <br>
    
    <div class="row justify-content-center">
                    <div class="col-lg-4">
                        <div class="login-content card">
                            <div class="login-form">
                                <img src="1.png" style="width:20%;"><br>
                                <form action="LoginStudent.php" method="POST">
                                    <div class="form-group">
                                        <label>Roll Number</label>
                                        <input type="number" name="srollnumber" class="form-control" placeholder="Roll Number" required="">
                                    </div>
                                    <div class="form-group">
                                        <label>Contact</label>
                                        <input type="number" name="scontact" class="form-control" placeholder="Contact" required="">
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                                <input type="checkbox"> Remember Me
                                            </label> 
                                           <label class="pull-right">
                                                <a href="forgetpassword.php">Forgotten Password?</a>
                                           </label>   
                                    </div><?php
                                   //  $query1="select * from add_student";
                                     //$result=mysqli_query($con,$query1);
                                     //$rows=mysqli_fetch_assoc($result)
                                  //while($rows=mysqli_fetch_assoc($result)){
                                
                                    ?>
                                    <button type="submit"  name="btn_login" class="btn btn-primary btn-flat m-b-30 m-t-30" >Sign in</button>
                                   <?php
                                  // }
                                   ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div> 
<b>------------------------or------------------------</b>
</div><div class="login-form ">
                                    <button type="submit"  name="btn_login" class="btn btn-primary btn-flat m-b-30 m-t-30" ><a href="SignupStudent.php">New User</a></button></div>
 </center>
</body>
</html>


<?php

if(isset($_POST['btn_login'])){
if(isset($_POST['srollnumber']))
$roll_num=$_POST['srollnumber'];
if(isset($_POST['scontact']))
$contact=$_POST['scontact'];
// echo $_SESSION['aemail']."\\\\\\   ".$_SESSION['apassword'];
// if(isset($_SESSION['aemail']))
// $email=$_POST['aemail'];
// if(isset($_SESSION['apassword']))
// $password=$_POST['apassword'];
}
//password matching
//$password=md5($password);
echo "hello";
if(!empty($roll_num) || !empty($contact)){
    $SELECT="SELECT * from add_student where srollnumber='$roll_num' and scontact='$contact'";
    $result=mysqli_query($con,$SELECT);
    if($result){
        echo "iiiii";
        $rows=mysqli_fetch_assoc($result);
       $name= $rows['sname'];
       $semester=$rows['ssemester'];
        $_SESSION['sname']=$name;
        $_SESSION['ssemester']=$semester;
        $num=mysqli_num_rows($result);
        if($num>0){
            ?>
            <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        
        <script>
        
        swal ( "success" ,  "congratulation!" ,  "success" )
    
         </script>

       
      <?php echo "<script>setTimeout(\"location.href = 'StudentHome.php';\",1500);</script>";  
        ?>
            <?php
           // echo "login successfully";
            //$_SESSION['srollnumber']=$roll_num;
           // header('location:StudentHome.php');
        }
        else
        {
            ?>
            <script>
              swal ( "Oops" ,  "Something went wrong!" ,  "error" )
            </script>
            
            <?php echo "<script>setTimeout(\"location.href = 'LoginStudent.php';\",1500);</script>";  
                ?>
             <?php
        }
    } 
}