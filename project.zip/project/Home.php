<?php include('myhead.php') ?>
<?php include('Admin.php') ?>
<center>
    <br>
    <div>
<div class="sem">
    <b> <a href="1stSem.php">1st Semister</a></b>
</div>

<br>
<div class="sem">
    <b> <a href="2ndSem.php" >2nd Semister</a></b>
</div>

<br>
<div class="sem">
    <b> <a href="3rdSem.php">3rd Semister</a></b>
</div>

<br>
<div class="sem">
    <b> <a href="4thSem.php">4th Semister</a></b>
</div>

<br>
<div class="sem">
    <b> <a href="5thSem.php">5th Semister</a></b>
</div>

<br>
<div class="sem">
    <b> <a href="6thSem.php">6th Semister</a></b>
</div>
</div>
</center>
