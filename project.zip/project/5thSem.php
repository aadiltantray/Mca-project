<?php include_once('myhead.php');?>
<?php include('Admin.php');?>
<style>
    .inline{
        display:inline-block;
        background: #c9e97f none repeat scroll 0 0;
  margin: 5px 0;
  padding: 32px;
  border: 0 solid #e7e7e7;
  border-radius: 80px;
  box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
  max-width: 56%;
    }

</style>
<center>
<div class="inline"  >
    <div class="green"> ~5th Semister~ </div><br>
<form action="save5thsem.php" method="POST" name="1st_sem">
     <div style="display:inline-block;">
<div class="inline">
                                             
                                                <label>Teacher Name</label>
                                                  <select type="text" name="Name" class="form-control"        placeholder="Name" id="event" onkeydown="return alphaOnly(event);" required="">
                                                
                                                  <option value="">--Select Teacher--</option>
                                                            <?php  
                                                            $c1 = "SELECT * FROM `add_teacher`";
                                                            $result = $con->query($c1);

                                                            if ($result->num_rows > 0) {
                                                                while ($row = mysqli_fetch_array($result)) {?>
                                                                    <option value="<?php echo $row["tname"];?>">
                                                                        <?php echo $row['tname'];?>
                                                                    </option>
                                                                    <?php
                                                                }
                                                            } else {
                                                            echo "0 results";
                                                                }
                                                            ?>
                                                    </select>
                                        
                                                  </div>
                                                  <div class="inline">
                                                <label class="col-sm-3 control-label">Subject Name</label>
                                                  <input type="text" name="Subject" class="form-control" placeholder="Subject" id="event" onkeydown="return alphaOnly(event);" required="">
                                                  </div>
                                                         <button type="submit" name="1st_sem" class="btn btn-primary btn-flat m-b-30 m-t-30">Submit</button> 
</div >  
</div>          
</div>                                           
</form>
</center>
<?php 
$name='';
$subject='';
$query1="select * from my_semester where Semester='5th Semester'";
$result=mysqli_query($con,$query1);
?>
<center>
<table style="width:35%">
<tr class="even">
  <th>Name</th>
  <th>Subject</th>
  <th>Action???</th>
  </tr>
  <?php
  while($rows=mysqli_fetch_assoc($result)) {?>

  <tr class="odd">
  <td><?php echo $rows['Name']; ?></td>
  <td><?php echo $rows['Subject']; ?></td>
  <td><button style="padding:0";><a href="EditSem5.php?edit=<?php echo $rows['id']; ?>"  onclick='return checkdelete()' class="edit" > Edit</a></button>
  <button style="padding:0";><a href="DeleteSem5.php?id=<?php echo $rows['id']; ?>"class="delete">delete</a></button>
</td>
</tr>
<?php
 }
  ?>
</table>
<script>
  function checkdelete()
  {
    return confirm('Are you sure you want to delete this record');
  }
</script>
</center>
