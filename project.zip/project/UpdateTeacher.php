<?php include('myhead.php')?> 
<?php
// if(isset($_GET['id']))
// {
// $id=$_GET['id'];
// if(isset($_GET['1st_sem'])){
// $name=$_GET['Name'];
// $subject=$_GET['Subject'];
// echo $subject;
// echo $q1="UPDATE `1st_sem` SET 'Name'=$name,`Subject`='$subject' WHERE `id`=$id";
// //$q1="UPDATE `1st_sem` SET 'Name'=$name,`Subject`='$subject' WHERE `id`='".$_GET['id']."'";
// //$query1="update '1st_sem' set Name='".$name."',Subject='".$subject."'";
// echo $result1=mysqli_query($con,$q1);

// if($result1)
// {
//     header('location:1stsem.php');

// }
// }
// else{
//     die(mysqli_error($con));
//     echo "please check again";
// }
// }
// else
// {
    
//     //header('location:1stSem.php');
//     echo "could not update";
// } 


//<?php include('myhead.php') ?>
<?php
include('connect.php');
//$name='';
//$subject='';
$update=false;
if(isset($_POST['1st_sem']))
if(isset($_POST['tname']))
$name=$_POST['tname'];
// if(isset($_POST['tlname']))
// $lastname=$_POST['tlname'];
if(isset($_POST['temail']))
$email=$_POST['temail'];
if(isset($_POST['tpassword']))
$password=$_POST['tpassword'];
if(isset($_POST['tgender']))
$gender=$_POST['tgender'];
if(isset($_POST['tdob']))
$dob=$_POST['tdob'];
if(isset($_POST['tcontact']))
$contact=$_POST['tcontact'];
if(isset($_POST['taddress']))
$address=$_POST['taddress'];
if(isset($_POST['Employee_id']))
$id=$_POST['Employee_id'];
echo "good";
//echo $name;
$id=$_POST['Employee_id'];
echo $id;
$query="UPDATE `add_teacher` SET tname ='$name',temail ='$email', tpassword ='$password', tgender ='$gender', tdob ='$dob', tcontact ='$contact', taddress ='$address'  WHERE Employee_id=$id";
//$query="UPDATE 1st_sem SET Name='$name',Subject='$subject' WHERE id=$id";
echo "nice";
echo $run=mysqli_query($con,$query);
echo $run;
if($run)
{
  echo "form submitted";
  header('location:viewTeacher.php');
}
else
{
echo "cannot delete";
die(mysqli_error($con));
}

// if(isset($_POST['edit'])){
//     $id=$_GET['edit'];
//     $update=true;
//     $result=$mysqli->query("UPDATE * from 1st_sem where id=$id") or die($mysqli->error());
//     if(count($result)==1)
//     {
//         $row=$result->fetch_array();
//         extract($row);
//         $name=$row['Name'];
//         $subject=$row['Subject'];
//     }
// }
// ?>
