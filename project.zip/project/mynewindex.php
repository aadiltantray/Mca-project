<?php include('head.php');?> 
<h3>Dashboard</h3>
<ol>
    <li>Home</li>
    <li>Dashboard</li>
</ol>