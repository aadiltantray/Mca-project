<?php
//checking error
error_reporting(0);
error_reporting(E_ALL);
ini_set('display_error',1);

$server="localhost";
$username="root";
$password="";
$database="mydb";
//establish connection with db
$con=mysqli_connect($server , $username,$password,$database);
if(!$con)
echo "Connection failed";
else{
echo "Connection done nnn   ";
//$adminlogin='admin1';
//$adminpassword='admin1';
//if(isset($_POST['Admin']))
$adminlogin=$_POST['Admin'];
//if(isset($_POST['password']))
 $adminpassword=$_POST['password'];
//$con=mysqli_connect('localhost','root','','mydb');
//$sql="CREATE DATABASE mydb";
//mysqli_query($con,$sql);
$a=mysqli_select_db($con,"mydb") or die("db not selectes" .mysql_error());
echo $a;


$mydata="SELECT * FROM loginadmin";
$data=mysqli_query($con,$mydata);
$total=mysqli_num_rows($data);
echo $total;
$result=mysqli_fetch_assoc($data);
//echo "<pre>";
//print_r($result);
//echo "</pre>";
//if(isset($result['Admin']))
echo $result['Admin'];
echo "        ";
echo $result['password'];



$q="INSERT INTO loginadmin (Admin,password) values ('$adminlogin','$adminpassword')";
echo $q;
echo "hello";
$i=mysqli_query($con,$q);
if(false===$i){
    printf("error:%s\n",mysqli_error($con));
}
    else {
        echo "done";
    }

echo $i;
echo " hi";

//mysqli_close($con);
echo " Welcome, you successfully loged
    in new";
}
?>
