<?php session_start();?>
<?php include('myhead.php');?>
<?php include('Admin.php');?>


<!-- //         $SELECT="SELECT aemail from loginadmin where aemail = ? Limit 1";
//         $INSERT="INSERT Into loginadmin ( aemail, apassword) values(?, ?)";
//         //prepare statement
// $stmt=$con->prepare($SELECT);
// $stmt->bind_param("s", $email);
// $stmt->execute();
// $stmt->bind_result($email);
// $stmt->store_result();
// $rnum=$stmt->num_rows;
// if($rnum==0) {
//     $stmt->close();
//     $stmt=$con->prepare($INSERT);
// $stmt->bind_param("ss",$email, $password);
// $stmt->execute();
// echo "New record insert successfully";
// //storing username and password in session variable
// $_SESSION['aemail']=$email;
// $_SESSION['apassword']=$password;
// if(!isset($_SESSION['aemail']))
// //  if(isset($_SESSION['apassword']){
// $_SESSION['success']="you have successfully loged in";
// //page redirection 
// // header('location:AddTeacher.php');
 
// }
// else {
//     echo "Someone already registered with this email";
// }
// echo "do it";
// $stmt->close();
// $con->close();
// }
// else {

//     echo "All fields are required";
//     die();
// }
// echo "thanku";
     
//  echo "invalid email password";
 
    // $q="INSERT INTO loginadmin (Admin,password) values ('$adminlogin','$adminpassword')";
    // echo $q;
    // echo "hello";
    // $i=mysqli_query($con,$q);
    // if(false===$i){
    //     printf("error:%s\n",mysqli_error($con));
    // }
    //     else {
    //         echo "done";
    //     }
    
    // echo $i;
    // echo " hi";
    
    // //mysqli_close($con);
    // echo " Welcome, you successfully loged
    //     in new";
    // }
    
    
  -->




<br>
<center><div class="login-content card">
    <div class="green"> ~New Student~ </div>

<br>
<form class="form-horizontal" method="POST" action="
SaveStudent.php" name="teacherform" enctype="multipart/form-data">
<!-- <div style="background-color:#a18af9; width:23%; height:30px;font-weight:bold;"  > -->
<?php  
                                                            //  $c1 = "SELECT  *  FROM `add_student` ORDER BY 'srollnumber' DESC LIMIT 1";
                                                            //  $result = $con->query($c1);

                                                            //  if (isset($result->num_rows) && $result->num_rows > 0) {
                                                            //      while ($row = mysqli_fetch_array($result)) {?>
                                                                        <!-- <option value="<?php // echo $row['srollnumber'];?>"><b> 
                                                                          <?php // echo " srollnumber : ". $row['srollnumber'];  
                                                                         ?>
                                                                         </b>
                                                                    </option> -->
                                                                     <?php
            //                                                     }
            //                                            } else {
            //    echo die(mysqli_error($con));                                            echo "0 results";
            //                                                 }
                                                            ?>
                                                            <!-- </div> -->
                                                            <br>
                                   <input type="hidden" name="currnt_date" class="form-control" value="<?php echo $currnt_date;?>">

                                         <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Name</label>
                                                <div class="col-sm-9">
                                                  <input type="text" name="sname" class="form-control" placeholder="Enter Name" id="event" onkeydown="return alphaOnly(event);" required="">
                                                </div>
                                            </div>
                                        </div>

                                        

                                       


                                        



                                                        <div class="form-group">
                                            <div class="row">

                                                <label class="col-sm-3 control-label">Email</label>
                                                <div class="col-sm-9">
                                                    <input type="text" name="semail" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"  placeholder="Email" required>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Semester</label>
                                                <div class="col-sm-9">
                                                  <select type="text" name="ssemester" class="form-control" placeholder="Semester" id="event" onkeydown="return alphaOnly(event);" required="">
                                                  <option value="">--Select Semester--</option>
                                                  <option value="1st Semester">1st Semester</option>
                                                  <option value="2nd Semester">2nd Semester</option>
                                                  <option value="3rd Semester">3rd Semester</option>
                                                  <option value="4th Semester">4th Semester</option>
                                                  <option value="5th Semester">5th Semester</option>
                                                  <option value="6th Semester">6th Semester</option>
            </select>
            </div>
                                                </div>
                                            </div>
                                        
                                         <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Roll Number</label>
                                                <div class="col-sm-9">
                                                    <input password="text" name="srollnumber" class="form-control" placeholder="Roll Number" id="tbNumbers" minlength="11" maxlength="11" onkeypress="javascript:return isNumber(event)" required="">
                                                </div>
                                            </div>
                                        </div>
                                       
                                          <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Gender</label>
                                                <div class="col-sm-9">
                                                   <select name="sgender" id="gender" class="form-control" required="">
                                                    <option value="">--Select Gender--</option>
                                                     <option value="Male">Male</option>
                                                      <option value="Female">Female</option>
                                                   </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                              <div class="row">
                                                <label class="col-sm-3 control-label">Date Of Birth</label>
                                                <div class="col-sm-9">
                                                  <input type="date" name="sdob" class="form-control" placeholder="Birth Date">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Contact</label>
                                                <div class="col-sm-9">
                                                    <input type="text" name="scontact" class="form-control" placeholder="Contact Number" id="tbNumbers" minlength="10" maxlength="10" onkeypress="javascript:return isNumber(event)" required="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Address</label>
                                                <div class="col-sm-9">
                                                    <textarea class="form-control" rows="4" name="saddress" placeholder="Address" style="height: 120px;"></textarea>
                                                </div>
                                            </div>
                                        </div>

                                        <button type="submit" name="btn_save" class="btn btn-primary btn-flat m-b-30 m-t-30">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                                                            
                  
                </div>
 </div> 
            
</center>     
 <?php include('footer.php');?>   