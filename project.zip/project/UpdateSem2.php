<?php include('myhead.php')?> 
<?php

// }
// else
// {
    
//     //header('location:1stSem.php');
//     echo "could not update";
// } 


//<?php include('myhead.php') ?>
<?php
include('connect.php');
//$name='';
//$subject='';
$update=false;
if(isset($_POST['1st_sem']))
if(isset($_POST['Name']))
$name=$_POST['Name'];
if(isset($_POST['Subject']))
$subject=$_POST['Subject'];
if(isset($_POST['id']))
$id=$_POST['id'];
echo "good";
echo $name;
$id=$_POST['id'];
echo $id;
$query="UPDATE `my_semester` SET Name ='$name',Subject ='$subject' WHERE id=$id";
//$query="UPDATE 1st_sem SET Name='$name',Subject='$subject' WHERE id=$id";
echo "nice";
echo $run=mysqli_query($con,$query);
echo $run;
if($run)
{
  echo "data updated";
  header('location:2ndSem.php');
}
else
{
echo "cannot update";
}

// if(isset($_POST['edit'])){
//     $id=$_GET['edit'];
//     $update=true;
//     $result=$mysqli->query("UPDATE * from 1st_sem where id=$id") or die($mysqli->error());
//     if(count($result)==1)
//     {
//         $row=$result->fetch_array();
//         extract($row);
//         $name=$row['Name'];
//         $subject=$row['Subject'];
//     }
// }
// ?>
